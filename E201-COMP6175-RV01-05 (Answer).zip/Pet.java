package FionaVarenciaTendio;

public class Pet {
	
	public Pet(int petHealth, String petName, String petType, String petSound) {
		super();
		this.petHealth = petHealth;
		this.petName = petName;
		this.petType = petType;
		this.petSound = petSound;
	}
	
	public int getPetHealth() {
		return petHealth;
	}
	public void setPetHealth(int petHealth) {
		this.petHealth = petHealth;
	}
	public String getPetName() {
		return petName;
	}
	public void setPetName(String petName) {
		this.petName = petName;
	}
	public String getPetType() {
		return petType;
	}
	public void setPetType(String petType) {
		this.petType = petType;
	}
	public String getPetSound() {
		return petSound;
	}
	public void setPetSound(String petSound) {
		this.petSound = petSound;
	}
	private int petHealth;
	private String petName;
	private String petType;
	private String petSound;
}
