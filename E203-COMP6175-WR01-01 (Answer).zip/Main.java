package EsterPricilliaEmmanuela;
import java.util.Scanner;
import java.util.Vector;
import java.util.Random;

public class Main {
	Scanner scan = new Scanner(System.in);
	Vector<Shoe>ShoeList = new Vector<>();
	Random rand  = new Random();
	
	void viewShoeData()
	{
		int jumlah = ShoeList.size();
		
		if(jumlah==0)
		{
			System.out.println("No shoes avaiable..");
			System.out.println("Press enter to continue..");
			scan.nextLine();
		}
		else
		{
			for(int i=0 ; i < ShoeList.size() ; i++)
			{
				System.out.println(i+1 +" " +ShoeList.get(i).getShoeName()+"-"+ShoeList.get(i).getShoeID());
				System.out.println("================");
				System.out.println("Category: "+ShoeList.get(i).getShoeCategory());
				System.out.println("Release date: "+ShoeList.get(i).getShoeReleaseDate());
				System.out.println("Price: "+ShoeList.get(i).getShoePrice());
				System.out.println();
			}
			System.out.println("Press enter to continue..");
			scan.nextLine();
		}
	}
	
	
	    

	
	void addShoeData()
	{
		String tempShoeName;
		String tempShoeCategory;
		String tempShoeReleaseDate,day,month,year;
		String releaseDate;
		int tempShoePrice,tempDay = 0,tempMonth = 0,tempYear = 0;
		String tempShoeID;
		String[] tampung;
		String[] tampung1;
		String[] tampung2;
		String alphabet = "a b c d e f g h i j k l m n o p q r s t u v w x y z";
	    String alphabet1 = "A B C D E F G H I J K L M N O P Q R S T U V W X Y Z";
	    tampung1 = alphabet.split(" ");
	    tampung2 = alphabet1.split(" ");
		   
		do{
			System.out.println("Input shoe's name[name ends with shoe, example: \"Fire Shoe\"]: ");
			tempShoeName = scan.nextLine();
		}while(!tempShoeName.contains(" shoe"));
		
		do{
			System.out.println("Input shoe's category[Sneaker | Running | Boot] (case sensitive): ");
			tempShoeCategory = scan.nextLine();
		}while(!tempShoeCategory.equals("Sneaker") && !tempShoeCategory.equals("Running") && !tempShoeCategory.equals("Boot"));
		
		do {
			System.out.println("Input shoe's release date[dd-mm-yyyy]: ");
			releaseDate = scan.nextLine();
//			for(int i=0;i<tampung1.length;i++)
//			{
//				while(releaseDate.contains(tampung1[i])||releaseDate.contains(tampung2[i]))
//				{
//					System.out.println("Input shoe's release date[dd-mm-yyyy]: ");
//					releaseDate = scan.nextLine();
//				}
//			}
			
		    tampung  = releaseDate.split("-");
		    
			try {
				tempDay = Integer.parseInt(tampung[0]);
				tempMonth = Integer.parseInt(tampung[1]);
				tempYear = Integer.parseInt(tampung[2]);
			} catch (NumberFormatException e) {
				System.out.println("Input shoe's release date[dd-mm-yyyy]: ");
				releaseDate = scan.nextLine();
			}
			
			tempShoeReleaseDate = String.format("%d-%d-%d", tempDay,tempMonth,tempYear);
		} while ((tempDay  < 1 || tempDay > 30) || (tempMonth < 1 || tempMonth > 12) || (tempYear < 2000 || tempYear > 2020) );
		
		do{
			System.out.println("Input shoe's price[more than or equals to 5000]: ");
			tempShoePrice = scan.nextInt();scan.nextLine();
		}while(tempShoePrice < 5000);
		
		tempShoeID = String.format("SH%3d", rand.nextInt(999));
		
		ShoeList.add(new Shoe(tempShoeName, tempShoeCategory, tempShoeReleaseDate, tempShoePrice, tempShoeID));
		System.out.println("Shoe added!");
		System.out.println("Press enter to continue...");
		scan.nextLine();
	}
	
	void deleteShoeData()
	{
		int delete;
		int jumlah = ShoeList.size();
		
		if(jumlah==0)
		{
			System.out.println("No shoes avaiable..");
			System.out.println("Press enter to continue..");
			scan.nextLine();
		}
		else
		{
			for(int i=0 ; i < ShoeList.size() ; i++)
			{
				System.out.println(i+1 +" " +ShoeList.get(i).getShoeName()+"-"+ShoeList.get(i).getShoeID());
				System.out.println("================");
				System.out.println("Category: "+ShoeList.get(i).getShoeCategory());
				System.out.println("Release date: "+ShoeList.get(i).getShoeReleaseDate());
				System.out.println("Price: "+ShoeList.get(i).getShoePrice());
				System.out.println();
			}
			
			do{
				System.out.println("Choose shoe's number to delete[1.."+ShoeList.size()+"]: ");
				delete = scan.nextInt();scan.nextLine();
			}while(delete < 0 || delete > ShoeList.size());
			
			ShoeList.remove(delete-1);
			System.out.println("Shoe removed!");
		}
	}
	
	public Main() {
		int choose;
		
		do{
			System.out.println("Shoe Shop");
			System.out.println("=========");
			System.out.println("1. View Shoes");
			System.out.println("2. Add Shoe");
			System.out.println("3. Delete Shoe");
			System.out.println("4. Exit");
			System.out.print(">> ");
			choose = scan.nextInt();scan.nextLine();
			
			switch(choose)
			{
			case 1:
				viewShoeData();
				break;
			case 2:
				addShoeData();
				break;
			case 3:
				deleteShoeData();
				break;
			case 4:
				System.out.println("Thank you for using this application!");
				break;
			}
		}while(choose > 4 || choose < 1 || choose!=4);
	}

	public static void main(String[] args) {
		new Main();
	}
}
