package EsterPricilliaEmmanuela;

public class Shoe {
	
	public Shoe(String shoeName, String shoeCategory, String shoeReleaseDate, int shoePrice, String shoeID) {
		super();
		this.shoeName = shoeName;
		this.shoeCategory = shoeCategory;
		this.shoeReleaseDate = shoeReleaseDate;
		this.shoePrice = shoePrice;
		this.shoeID = shoeID;
	}
	public String getShoeName() {
		return shoeName;
	}
	public void setShoeName(String shoeName) {
		this.shoeName = shoeName;
	}
	public String getShoeCategory() {
		return shoeCategory;
	}
	public void setShoeCategory(String shoeCategory) {
		this.shoeCategory = shoeCategory;
	}
	public String getShoeReleaseDate() {
		return shoeReleaseDate;
	}
	public void setShoeReleaseDate(String shoeReleaseDate) {
		this.shoeReleaseDate = shoeReleaseDate;
	}
	public int getShoePrice() {
		return shoePrice;
	}
	public void setShoePrice(int shoePrice) {
		this.shoePrice = shoePrice;
	}
	public String getShoeID() {
		return shoeID;
	}
	public void setShoeID(String shoeID) {
		this.shoeID = shoeID;
	}
	private String shoeName;
	private String shoeCategory;
	private String shoeReleaseDate;
	private int shoePrice;
	private String shoeID;
}
