package FionaVarenciaTendio;
import java.util.Scanner;
import java.util.Vector;

public class InventoryManagementSystem {
	Scanner scan = new Scanner(System.in);
	Vector<Inventory>InventoryList = new Vector<>();
	
	boolean checkUniqueInventoryID(String InventoryID)
	{
		for(int i=0; i < InventoryList.size();i++)
		{
			if(InventoryList.get(i).getInventoryID().equals(InventoryID))
			{
				return true;
			}
		}
		return false;
	}
	void viewInventoryData()
	{
		int jumlah = InventoryList.size();
		
		if(jumlah==0)
		{
			System.out.println("No items in inventory");
			System.out.println("Press enter to continue . . . ");
			scan.nextLine();
		}
		else
		{
			System.out.println("======================================================");
			System.out.println("|  List of items in Inventory                        |");
			System.out.println("======================================================");
			for(int i=0 ; i < InventoryList.size();i++)
			{
				System.out.printf("| %-5s | %27s |  %-5d |  %-2d |\n", InventoryList.get(i).getInventoryID(),InventoryList.get(i).getInventoryName(),InventoryList.get(i).getInventoryPrice(),InventoryList.get(i).getInventoryStock());
			}
			System.out.println("======================================================");
			System.out.println();
			System.out.println("Press Enter to Continue . . . ");
			scan.nextLine();
		}
	}
	
	void addORupdateInventoryData()
	{
		String tempInventoryID;
		String tempInventoryName;
		int tempInventoryPrice;
		int tempInventoryStock;
		boolean penanda = true;
		
		do{
			System.out.print("Input Item ID[XXXXX]: ");
			tempInventoryID = scan.nextLine();
		}while(tempInventoryID.length() < 5 || tempInventoryID.length() > 5);
		
		
		for(int i=0;i<InventoryList.size();i++)
		{
			if(tempInventoryID.equals(InventoryList.get(i).getInventoryID()))
			{
				penanda = false;
			}
			else
			{
				penanda = true;
			}
		}
		if(penanda==true)
		{
			do{
				System.out.print("Input Item Name[5-28]: ");
				tempInventoryName = scan.nextLine();
			}while(tempInventoryName.length() < 5 || tempInventoryName.length() > 28);
			
			do {
				System.out.print("Input Item Price[Min 10000]: ");
			    while (!scan.hasNextInt()) {
			    	System.out.println("Input must be a number");
			    	System.out.print("Input Item Price[Min 10000]: ");
			        scan.next(); scan.nextLine();
			    }
			    tempInventoryPrice = scan.nextInt();scan.nextLine();
			} while(tempInventoryPrice < 10000);
			
			do {
				System.out.print("Input Item Stock[Min 10]: ");
			    while (!scan.hasNextInt()) {
			    	System.out.println("Input must be a number");
			    	System.out.print("Input Item Stock[Min 10]: ");
			        scan.next(); scan.nextLine();
			    }
			    tempInventoryStock = scan.nextInt();scan.nextLine();
			} while(tempInventoryStock < 10);
			
			InventoryList.add(new Inventory(tempInventoryID, tempInventoryName, tempInventoryPrice, tempInventoryStock));
			System.out.println();
			System.out.println();
			System.out.println("Success adding item to inventory");
			System.out.println();
			System.out.println("Press Enter to Continue . . . ");
			scan.nextLine();
		}
		else
		{
			System.out.println("Your Item is already exist");
			System.out.println("--------------------------");
			System.out.println();
			for(int j=0;j<InventoryList.size();j++)
			{
				if(tempInventoryID.equals(InventoryList.get(j).getInventoryID()))
				{
					System.out.println("Item ID: "+InventoryList.get(j).getInventoryID());
					System.out.println("Item Name: "+InventoryList.get(j).getInventoryName());
					System.out.println("Item Price: "+InventoryList.get(j).getInventoryPrice());
					System.out.println(">> Current Item Stock: "+InventoryList.get(j).getInventoryStock());
					
					System.out.println();
					System.out.println();
					
					
						System.out.print("Input Item Stock to be Added: ");
					    while (!scan.hasNextInt()) {
					    	System.out.println("Input must be a number");
					    	System.out.print("Input Item Stock to be Added: ");
					        scan.next(); scan.nextLine();
					    }
					    tempInventoryStock = scan.nextInt();scan.nextLine();
					    
					    InventoryList.get(j).setInventoryStock(tempInventoryStock);
					    System.out.println();
					    System.out.println();
					    System.out.println("Success Update Item Stock");
					    System.out.println("Press Enter to Continue");
				}
			}
			
		}
	}
	
	void sellInventoryData()
	{
		int jumlah = InventoryList.size();
		String tempInventoryID;
		
		
		if(jumlah==0)
		{
			System.out.println("No items in inventory");
			System.out.println("Press enter to continue . . . ");
			scan.nextLine();
		}
		else
		{
			boolean check = false;
			int indeks = 0;
			int jualStock;
			System.out.println("======================================================");
			System.out.println("|  List of items in Inventory                        |");
			System.out.println("======================================================");
			for(int i=0 ; i < InventoryList.size();i++)
			{
				System.out.printf("| %-5s | %27s |  %-5d |  %-2d |\n", InventoryList.get(i).getInventoryID(),InventoryList.get(i).getInventoryName(),InventoryList.get(i).getInventoryPrice(),InventoryList.get(i).getInventoryStock());
			}
			System.out.println("======================================================");
			System.out.println();
			do{
				System.out.println("Input Item ID to be Checked Out: ");
				tempInventoryID = scan.nextLine();
				check = checkUniqueInventoryID(tempInventoryID);
			}while(!check);
			for(int i=0 ; i < InventoryList.size();i++)
			{
				if(tempInventoryID.equals(InventoryList.get(i).getInventoryID()))
				{
					indeks = i;
				}
			}
			if( InventoryList.get(indeks).getInventoryStock()==0)
			{
				System.out.println("Cannot Checkout, item is out of stock!!");
				System.out.println("Press Enter to Continue . . . ");
				scan.nextLine();
			}
			else
			{
				do{
					
					System.out.println("Input Item Stock to be Checked Out[1-"+InventoryList.get(indeks).getInventoryStock()+"]: ");
					 while (!scan.hasNextInt()) {
					    	System.out.println("Input must be a number");
					    	System.out.println("Input Item Stock to be Checked Out[1-"+InventoryList.get(indeks).getInventoryStock()+"]: ");
					        scan.next(); scan.nextLine();
					    }
					jualStock = scan.nextInt();scan.nextLine();
				}while(jualStock < 1 || jualStock > InventoryList.get(indeks).getInventoryStock());
				
				InventoryList.get(indeks).setInventoryStock(InventoryList.get(indeks).getInventoryStock()-jualStock);
				int totalRevenue = jualStock*InventoryList.get(indeks).getInventoryPrice();
				
				System.out.println();
				System.out.println();
				System.out.println("You have sold "+jualStock+" of "+InventoryList.get(indeks).getInventoryName()+" with revenue Rp."+totalRevenue);
				System.out.println("Press Enter to Continue . . . ");
				scan.nextLine();
			}
			
		}
	}
	
	public InventoryManagementSystem() {
		int choose;
		
		do{
			System.out.println("Inventory Management System");
			System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=");
			System.out.println("1. View Item in Inventory");
			System.out.println("2. Add New Item to Inventory");
			System.out.println("3. Checkout Item from Inventory");
			System.out.println("4. Exit");
			System.out.println("Choose : ");
			choose = scan.nextInt();scan.nextLine();
			
			switch(choose)
			{
			case 1:
				viewInventoryData();
				break;
			case 2:
				addORupdateInventoryData();
				break;
			case 3:
				sellInventoryData();
				break;
			}
		}while(choose > 4 || choose < 1 || choose!=4);
	}

	public static void main(String[] args) {
		new InventoryManagementSystem();
	}
}
