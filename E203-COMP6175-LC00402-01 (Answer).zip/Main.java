package LC00402_01;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;
public class Main {
	Scanner scan = new Scanner(System.in);
	Vector<Weapon>WeaponList = new Vector<>();
	Random rand = new Random();
	
	boolean checkUniqueWeaponName(String WeaponName)
	{
		for(int i=0; i < WeaponList.size();i++)
		{
			if(WeaponList.get(i).getWeaponName().equals(WeaponName))
			{
				return true;
			}
		}
		return false;
	}
	
	void addWeaponData()
	{
		String tempWeaponID;
		String tempWeaponName;
		String tempWeaponQuality;
		int tempWeaponPower = 0;
		int tempWeaponPrice = 0;
		boolean check = false;
		
		tempWeaponID = String.format("%c%c%3d", (char)(rand.nextInt(26) + 'A'), (char)(rand.nextInt(26) + 'A'), (rand.nextInt(999)));
		
		do{
			System.out.print("Input weapon name [3-12 Character] : ");
			tempWeaponName = scan.nextLine();
			check = checkUniqueWeaponName(tempWeaponName);
		}while(check || tempWeaponName.length() < 3 || tempWeaponName.length() > 12);
		
		do{
			System.out.print("Input weapon quality [Low | Medium | High](Case Sensitive) : ");
			tempWeaponQuality = scan.nextLine();
		}while(!tempWeaponQuality.equals("Low") && !tempWeaponQuality.equals("Medium") && !tempWeaponQuality.equals("High"));
		
		if(tempWeaponQuality.equals("Low"))
		{
			tempWeaponPower = rand.nextInt(5000);
			tempWeaponPrice = 2000 + tempWeaponPower;
		}
		else if(tempWeaponQuality.equals("Medium"))
		{
			tempWeaponPower = 5000 + rand.nextInt(5000);
			tempWeaponPrice = 3000 + tempWeaponPower;
		}
		else if(tempWeaponQuality.equals("High"))
		{
			tempWeaponPower = 10000 + rand.nextInt(5000);
			tempWeaponPrice = 4000 + tempWeaponPower;
		}
		WeaponList.add(new Weapon(tempWeaponID, tempWeaponName, tempWeaponQuality, tempWeaponPower, tempWeaponPrice));
		System.out.println("Add weapon success");
	}
	
	void viewWeaponData()
	{
		int jumlah = WeaponList.size();
		
		if(jumlah==0)
		{
			System.out.println("There is no data..");
			System.out.println("Press enter to continue..");
			scan.nextLine();
		}
		else
		{
			System.out.println("=============================================================");
			System.out.println("| No | ID    | Name          | Quality | Power | Price      |");
			System.out.println("=============================================================");
			for (int i = 0; i < WeaponList.size(); i++) {
				System.out.printf("| %-2d | %-5s | %-13s | %-7s | %-5d | %-10d |\n",  i+1,WeaponList.get(i).getWeaponID(),WeaponList.get(i).getWeaponName(),WeaponList.get(i).getWeaponQuality(),WeaponList.get(i).getWeaponPower(),WeaponList.get(i).getWeaponPrice());
			}
			System.out.println("=============================================================");
			
			System.out.println("Press enter to continue...");
			scan.nextLine();
		}
	}
	
	void deleteWeaponData()
	{
		int jumlah = WeaponList.size();
		int delete;
		
		if(jumlah==0)
		{
			System.out.println("There is no data..");
			System.out.println("Press enter to continue..");
			scan.nextLine();
		}
		else
		{
			System.out.println("=============================================================");
			System.out.println("| No | ID    | Name          | Quality | Power | Price      |");
			System.out.println("=============================================================");
			for (int i = 0; i < WeaponList.size(); i++) {
				System.out.printf("| %-2d | %-5s | %-13s | %-7s | %-5d | %-10d |\n",  i+1,WeaponList.get(i).getWeaponID(),WeaponList.get(i).getWeaponName(),WeaponList.get(i).getWeaponQuality(),WeaponList.get(i).getWeaponPower(),WeaponList.get(i).getWeaponPrice());
			}
			System.out.println("=============================================================");
			do{
				System.out.println("Input index [1-"+WeaponList.size()+" | 0 to cancel]:");
				delete = scan.nextInt();scan.nextLine();
				if(delete==0)
				{
					return;
				}
			}while(delete < 0 || delete > WeaponList.size());
			WeaponList.remove(delete-1);
		}
	}
	
	public Main() {
		int choose;
		
		do{
			System.out.println("Menu");
			System.out.println("1. Add Weapon");
			System.out.println("2. View Weapon");
			System.out.println("3. Delete Weapon");
			System.out.println("4. Exit");
			System.out.println("Choose : ");
			choose = scan.nextInt();scan.nextLine();
			
			switch(choose)
			{
			case 1:
				addWeaponData();
				break;
			case 2:
				viewWeaponData();
				break;
			case 3:
				deleteWeaponData();
				break;
			}
		}while(choose > 4 || choose < 1 || choose != 4);
	}

	public static void main(String[] args) {
		new Main();
	}

}
