package LC00402_01;

public class Weapon {
	private String weaponID;
	private String weaponName;
	private String weaponQuality;
	private int weaponPower;
	private int weaponPrice;
	
	public Weapon(String weaponID, String weaponName, String weaponQuality, int weaponPower, int weaponPrice) {
		super();
		this.weaponID = weaponID;
		this.weaponName = weaponName;
		this.weaponQuality = weaponQuality;
		this.weaponPower = weaponPower;
		this.weaponPrice = weaponPrice;
	}

	public String getWeaponID() {
		return weaponID;
	}

	public void setWeaponID(String weaponID) {
		this.weaponID = weaponID;
	}

	public String getWeaponName() {
		return weaponName;
	}

	public void setWeaponName(String weaponName) {
		this.weaponName = weaponName;
	}

	public String getWeaponQuality() {
		return weaponQuality;
	}

	public void setWeaponQuality(String weaponQuality) {
		this.weaponQuality = weaponQuality;
	}

	public int getWeaponPower() {
		return weaponPower;
	}

	public void setWeaponPower(int weaponPower) {
		this.weaponPower = weaponPower;
	}

	public int getWeaponPrice() {
		return weaponPrice;
	}

	public void setWeaponPrice(int weaponPrice) {
		this.weaponPrice = weaponPrice;
	}
}
